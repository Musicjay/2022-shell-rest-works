# to run 

> mvn clean install

> mvn spring-boot:run
