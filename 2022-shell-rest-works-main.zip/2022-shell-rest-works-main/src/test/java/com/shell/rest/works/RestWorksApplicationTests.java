package com.shell.rest.works;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWorksApplicationTests {

	@Test
	void contextLoads() {
	}

}
